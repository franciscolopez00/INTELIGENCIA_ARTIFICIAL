import java.util.*;

public class BusquedasNoInformadas {

    public static void main(String[] args) {
        // Armamos un grafo de prueba (inspirado en puntos de Culiacan)
        Nodo tec = new Nodo("Tecnologico");
        Nodo centro = new Nodo("Centro");
        Nodo lomita = new Nodo("La Lomita");
        Nodo forum = new Nodo("Forum");
        Nodo botanico = new Nodo("Jardin Botanico");
        Nodo tresRios = new Nodo("Tres Rios");

        // Conexiones y "costo" o distancia ficticia
        tec.agregarVecino(centro, 5.0);
        tec.agregarVecino(lomita, 7.0);
        centro.agregarVecino(forum, 4.0);
        centro.agregarVecino(lomita, 3.0);
        lomita.agregarVecino(tresRios, 6.0);
        forum.agregarVecino(tresRios, 2.0);
        forum.agregarVecino(botanico, 5.0);
        tresRios.agregarVecino(botanico, 3.0);

        Nodo inicio = tec;
        Nodo meta = botanico;

        List<Resultado> resultados = new ArrayList<>();

        // Ejecutamos todos los algoritmos
        resultados.add(ejecutarBFS(inicio, meta));
        resultados.add(ejecutarDFS(inicio, meta));
        resultados.add(ejecutarUCS(inicio, meta));
        resultados.add(ejecutarIDDFS(inicio, meta, 10)); // Limite de profundidad 10
        resultados.add(ejecutarBidireccional(inicio, meta));

        // Imprimir la tabla comparativa por consola
        imprimirTabla(resultados);
    }

    // --- ALGORITMOS DE BUSQUEDA ---

    // A. Busqueda en Anchura (BFS)
    static Resultado ejecutarBFS(Nodo inicio, Nodo meta) {
        Resultado res = new Resultado("Anchura (BFS)");
        long tInicio = System.nanoTime();
        
        Queue<Nodo> cola = new LinkedList<>();
        Set<Nodo> visitados = new HashSet<>();
        cola.add(inicio);
        visitados.add(inicio);

        while (!cola.isEmpty()) {
            Nodo actual = cola.poll();
            res.nodosExpandidos++;
            if (actual == meta) { res.exito = true; break; }
            
            for (Arista a : actual.vecinos) {
                if (!visitados.contains(a.destino)) {
                    visitados.add(a.destino);
                    cola.add(a.destino);
                }
            }
        }
        res.tiempoMs = (System.nanoTime() - tInicio) / 1_000_000.0;
        return res;
    }

    // B. Busqueda en Profundidad (DFS)
    static Resultado ejecutarDFS(Nodo inicio, Nodo meta) {
        Resultado res = new Resultado("Profundidad (DFS)");
        long tInicio = System.nanoTime();
        
        Stack<Nodo> pila = new Stack<>();
        Set<Nodo> visitados = new HashSet<>();
        pila.push(inicio);

        while (!pila.isEmpty()) {
            Nodo actual = pila.pop();
            if (!visitados.contains(actual)) {
                visitados.add(actual);
                res.nodosExpandidos++;
                if (actual == meta) { res.exito = true; break; }
                
                for (Arista a : actual.vecinos) {
                    if (!visitados.contains(a.destino)) {
                        pila.push(a.destino);
                    }
                }
            }
        }
        res.tiempoMs = (System.nanoTime() - tInicio) / 1_000_000.0;
        return res;
    }

    // C. Busqueda de Costo Uniforme (UCS)
    static Resultado ejecutarUCS(Nodo inicio, Nodo meta) {
        Resultado res = new Resultado("Costo Uniforme");
        long tInicio = System.nanoTime();
        
        PriorityQueue<NodoCosto> frontera = new PriorityQueue<>();
        Set<Nodo> explorados = new HashSet<>();
        frontera.add(new NodoCosto(inicio, 0.0));

        while (!frontera.isEmpty()) {
            NodoCosto actual = frontera.poll();
            if (explorados.contains(actual.nodo)) continue;
            explorados.add(actual.nodo);
            res.nodosExpandidos++;

            if (actual.nodo == meta) {
                res.exito = true;
                break;
            }

            for (Arista a : actual.nodo.vecinos) {
                if (!explorados.contains(a.destino)) {
                    frontera.add(new NodoCosto(a.destino, actual.costoAcumulado + a.costo));
                }
            }
        }
        res.tiempoMs = (System.nanoTime() - tInicio) / 1_000_000.0;
        return res;
    }

    // D. Profundidad Iterativa (IDDFS)
    static Resultado ejecutarIDDFS(Nodo inicio, Nodo meta, int maxProfundidad) {
        Resultado res = new Resultado("Prof. Iterativa");
        long tInicio = System.nanoTime();
        
        for (int limite = 0; limite <= maxProfundidad; limite++) {
            Set<Nodo> visitados = new HashSet<>();
            if (dls(inicio, meta, limite, visitados, res)) {
                res.exito = true;
                break;
            }
        }
        res.tiempoMs = (System.nanoTime() - tInicio) / 1_000_000.0;
        return res;
    }

    // Metodo recursivo de soporte para IDDFS
    static boolean dls(Nodo actual, Nodo meta, int limite, Set<Nodo> visitados, Resultado res) {
        res.nodosExpandidos++;
        if (actual == meta) return true;
        if (limite <= 0) return false;
        
        visitados.add(actual);
        for (Arista a : actual.vecinos) {
            if (!visitados.contains(a.destino)) {
                if (dls(a.destino, meta, limite - 1, visitados, res)) return true;
            }
        }
        visitados.remove(actual); // Backtracking
        return false;
    }

    // E. Busqueda Bidireccional
    static Resultado ejecutarBidireccional(Nodo inicio, Nodo meta) {
        Resultado res = new Resultado("Bidireccional");
        long tInicio = System.nanoTime();

        Queue<Nodo> colaInicio = new LinkedList<>();
        Queue<Nodo> colaMeta = new LinkedList<>();
        Set<Nodo> visitadosInicio = new HashSet<>();
        Set<Nodo> visitadosMeta = new HashSet<>();

        colaInicio.add(inicio);
        colaMeta.add(meta);
        visitadosInicio.add(inicio);
        visitadosMeta.add(meta);

        boolean cruzados = false;

        while (!colaInicio.isEmpty() && !colaMeta.isEmpty() && !cruzados) {
            // Expandir desde el inicio
            Nodo actualInicio = colaInicio.poll();
            res.nodosExpandidos++;
            if (visitadosMeta.contains(actualInicio)) { res.exito = true; cruzados = true; break; }

            for (Arista a : actualInicio.vecinos) {
                if (!visitadosInicio.contains(a.destino)) {
                    visitadosInicio.add(a.destino);
                    colaInicio.add(a.destino);
                }
            }

            // Expandir desde la meta
            Nodo actualMeta = colaMeta.poll();
            res.nodosExpandidos++;
            if (visitadosInicio.contains(actualMeta)) { res.exito = true; cruzados = true; break; }

            for (Arista a : actualMeta.vecinos) {
                if (!visitadosMeta.contains(a.destino)) {
                    visitadosMeta.add(a.destino);
                    colaMeta.add(a.destino);
                }
            }
        }
        res.tiempoMs = (System.nanoTime() - tInicio) / 1_000_000.0;
        return res;
    }

    // Imprime la tabla comparativa con formato
    static void imprimirTabla(List<Resultado> resultados) {
        System.out.println("==================================================================");
        System.out.printf("%-20s | %-10s | %-15s | %-12s%n", "Algoritmo", "Exito?", "Tiempo (ms)", "Nodos Exp.");
        System.out.println("==================================================================");
        for (Resultado r : resultados) {
            System.out.printf("%-20s | %-10s | %-15.4f | %-12d%n", 
                    r.algoritmo, (r.exito ? "Si" : "No"), r.tiempoMs, r.nodosExpandidos);
        }
        System.out.println("==================================================================");
    }
}
