public class Arista {
    public Nodo destino;
    public double costo;

    public Arista(Nodo destino, double costo) {
        this.destino = destino;
        this.costo = costo;
    }
}
