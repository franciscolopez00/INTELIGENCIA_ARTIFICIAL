import java.util.ArrayList;
import java.util.List;

public class Nodo {
    public String nombre;
    public List<Arista> vecinos;

    public Nodo(String nombre) {
        this.nombre = nombre;
        this.vecinos = new ArrayList<>();
    }

    public void agregarVecino(Nodo destino, double costo) {
        this.vecinos.add(new Arista(destino, costo));
        destino.vecinos.add(new Arista(this, costo)); // Es un grafo bidireccional (no dirigido)
    }
}
