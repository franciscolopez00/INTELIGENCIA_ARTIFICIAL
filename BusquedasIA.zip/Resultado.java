public class Resultado {
    public String algoritmo;
    public boolean exito;
    public int nodosExpandidos;
    public double tiempoMs;
    
    public Resultado(String alg) { 
        this.algoritmo = alg; 
    }
}
