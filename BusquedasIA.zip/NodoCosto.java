public class NodoCosto implements Comparable<NodoCosto> {
    public Nodo nodo;
    public double costoAcumulado;

    public NodoCosto(Nodo n, double c) { 
        this.nodo = n; 
        this.costoAcumulado = c; 
    }

    @Override
    public int compareTo(NodoCosto otro) { 
        return Double.compare(this.costoAcumulado, otro.costoAcumulado); 
    }
}
